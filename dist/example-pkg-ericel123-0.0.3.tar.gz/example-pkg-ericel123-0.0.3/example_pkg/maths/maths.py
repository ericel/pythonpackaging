class math(object):
    """
    Addition
    Add to numbers
    """
    def Addition(a, b):
        try:
            return a + b
        except:
            return 'ERROR: Make sure you enter a real or whole number!'